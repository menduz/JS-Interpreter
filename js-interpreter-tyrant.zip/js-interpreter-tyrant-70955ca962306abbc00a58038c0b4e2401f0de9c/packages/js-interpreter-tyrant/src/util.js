export function shortTestName(path) {
  return path.split('test262/test/')[1];
}
