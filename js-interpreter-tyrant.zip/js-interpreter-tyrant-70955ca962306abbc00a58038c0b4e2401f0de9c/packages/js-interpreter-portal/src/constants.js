export const ClientEvents = {
  TYRANT_EVENT: 'TYRANT_EVENT',
};
