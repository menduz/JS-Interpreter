import { Lock } from '../util';

export const rootLock = new Lock('slave-root');
